﻿using OutlookInspired.Module.BusinessObjects;
using OutlookInspired.Win.Extensions;

namespace OutlookInspired.Win.UserControls
{
    public partial class EmployeesLayoutView : ColumnViewUserControl
    {
        public EmployeesLayoutView()
        {
            InitializeComponent();
            DataSourceOrFilterChanged += (_, _) => labelControl1.Text = $@"RECORDS: {ColumnView.DataRowCount.ToString()}";
        }

        protected override Type GetObjectType()
        {
            return typeof(Employee);
        }



    }
}