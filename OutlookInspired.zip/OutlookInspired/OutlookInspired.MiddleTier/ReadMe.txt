﻿Project Description

This project implements an ASP.NET Core Web API application (https://docs.devexpress.com/eXpressAppFramework/403394/backend-web-api-service).
The appsettings.json file contains database connection, logging, and authentication settings (https://docs.microsoft.com/en-us/aspnet/core/fundamentals/configuration).

YOUR FEEDBACK MATTERS
Please tell us how our Web API Service works for you: https://www.devexpress.com/go/XAF_WebAPI_Feedback.aspx - THANKS!

Relevant Documentation

Backend Web API Service
https://docs.devexpress.com/eXpressAppFramework/403394/backend-web-api-service

Overview
https://www.devexpress.com/products/net/application_framework/security-web-api-service.xml