﻿using DevExpress.ExpressApp;
using DevExpress.ExpressApp.DC;
using OutlookInspired.Module.Attributes;

namespace OutlookInspired.Module.BusinessObjects{
    [DomainComponent]
    
    public class UserControlObject:NonPersistentBaseObject{
		
    }
}